# Thanks for contributing to GNPy

If it isn't much trouble, please send your contribution as patches to our Gerrit.
Here's [how to submit patches](https://review.gerrithub.io/Documentation/intro-gerrit-walkthrough-github.html), and here's a [list of stuff we are currently working on](https://review.gerrithub.io/p/Telecominfraproject/oopt-gnpy/+/dashboard/main:main).
Just sign in via your existing GitHub account.

However, if you feel more comfortable with filing GitHub PRs, we can work with that too.
