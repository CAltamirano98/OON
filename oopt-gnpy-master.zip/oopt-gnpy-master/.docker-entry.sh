#!/bin/bash
cp -nr /oopt-gnpy/gnpy/example-data /shared
exec "$@"
