#!/bin/bash
cp -nr /oopt-gnpy/examples /shared
exec "$@"
