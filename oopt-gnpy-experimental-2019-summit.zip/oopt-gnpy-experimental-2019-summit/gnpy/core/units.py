#!/usr/bin/env python3
# -*- coding: utf-8 -*-

UNITS = {'m': 1,
         'km': 1E3}
